import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class Settings {
    public Color colors;
/**
    Variables v = new Variables();
String Settingss = v.Settings;
    public void ReadSettings() throws Exception
    {
        String[] data = new String[1];
        File file  = new File(Settingss);
        BufferedReader br = new BufferedReader(new FileReader(file));
        data[0] = br.readLine();
        System.out.println(data[0]);
        if(data[0].equals("GRAY"))
        {
            colors = Color.GRAY;
        }
        else {
            colors = Color.GRAY;
        }
        SetSetting(20,colors);
    }


    public void SetSetting(int font,Color color)
    {
        gui g= new gui();
        g.home.setFont(new Font("Serif", Font.PLAIN, 32+font));
        g.question.setFont(new Font("Serif", Font.PLAIN, font));
        g.answer.setFont(new Font("Serif", Font.PLAIN, font));
        g.rootName.setBackground(color);
        g.tab1.setBackground(color);
        g.tab2.setBackground(Color.GRAY);
        g.panel1.setBackground(Color.GRAY);
        g.panel2.setBackground(Color.GRAY);
        g.panel3.setBackground(Color.GRAY);
        g.panel4.setBackground(Color.GRAY);
        g.panel5.setBackground(Color.GRAY);
        g.panel6.setBackground(Color.GRAY);
        g.panel7.setBackground(Color.GRAY);
        g.panel8.setBackground(Color.GRAY);
        g.setBackground(Color.GRAY);

    }
**/
}
