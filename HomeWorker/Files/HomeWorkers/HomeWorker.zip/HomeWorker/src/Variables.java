public class Variables {
    public String HomeWorks = "Files/HomeWorks";
    public String Settings = "Files/Settings";


}
